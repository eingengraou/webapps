<!DOCTYPE html>
<html>

<head>
	<title> CLAIRE ANNE STEINGLASS | Investment Advisor</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="description" content="Investment Advisor , Bitcoin,  Trading">
    <meta name="keywords" content="claire, anne, steinglass">
    <meta name="author" content="claire anne steinglass">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="index.css">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>

<body style="background:#F9F9F9;">
	
	<section class="">
		<div class="container">
			<div class="row  justify-content-center pt-5">
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7 pt-5">
					<div class="jumbotron py-t text-center">
						<h3>Your Journey Starts here</h3>
						<p class="lead">Let me help you take the first step you deserve to feel comfortable in finding confidence in yourself and becoming the best you can be.</p>
					</div>
					<div class="row justify-content-center">
						<div class="text-center">
							<a href="mailto:contact@claireannesteinglass.com" class="btn btn-primary btn-lg mx-2 my-2" style="background:#212529;">Send Mail</a>
							<a href="https://wa.me/16174106260" class="btn btn-primary btn-lg mx-2 my-2" style="background:#212529;">Send a whatsapp message</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="section about pb-5">
		<div class="container pb-5">
			<div class="jumbotron ">
				<h1 class="my-5 text-center">ABOUT ME / <span style="color:#EBEBEB;">HOME</span></h1>
				<div class="jumbotron my-5">
					<div class="row justify-content-center">
						<div class="col-lg-4 col-md-4 col-sm-12 px-2">
							<img src="assets/about.jpeg"  style="width:100%; height:350px;box-shadow: -20px -20px #21262D; border:solid; border-right:30px; border-bottom:30px;background:#EBEBEB;" class="py-2 px-2">
							<figcaption class="px-5" style="background:#21262D; color:#EBEBEB; margin-top:-2rem;position:relative;z-index:100;opacity:0.7;">NAME : CLAIRE ANNE STEINGLASS<br>Financial Expert/Consultant</figcaption>
						</div>
						
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 px-2 mt-5">
							<div class="container">
								<h1>HELLO  <span class="h1"></span></h1>
								<h5>Certified Financial Expert/Consultant</h5>
								<hr style="width:150px; height:3px; margin-left:5rem;">
								<p> Claire Anne Steinglass is a financial advisor who understands that, there’s more to financial planning than helping you decide how to invest.Claire is a verified Top US financial Consultant with over 11 years of experience and have bagged license is different states in the United States of America. </p>
								
								<p>My main focus will continue to increase in trading and investing. This is what lights a fire within me, that gets me giddy like nothing else because it’s something am very good at and I love to do it. No matter the business, we believe if we do what’s right for clients, we’ll help them achieve success while also realizing our own.</p>
								
								<p>I provide advice about securities to clients; In addition, managing investment portfolios and offer financial planning services.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="section experience py-5" style="background:#21262D; color:white;">
		<div class="container py-5">
			<h1>EXPERIENCE</h1>
			<hr style="width:150px; height:3px; margin-left:5rem;">
			<ul class="exp col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<li class="col-lg-12 col-md-12 col-sm-12 col-xs-12  py-3 px-auto">
					<div class="exam" style="font-size:22px;">
						SIE - Securities Industry Essentials Examination
					</div>
					<p class="date" style="font-size:20px">Oct 1, 2018</p>
					<p class="last">General Industry/Products Exam</p>
				</li>
				
				<li class="col-lg-12 col-md-12 col-sm-12 col-xs-12  py-3 px-auto">
					<div class="exam" style="font-size:22px;">
						Series 66 - Uniform Combined State Law Examination
					</div>
					<p class="date" style="font-size:20px">Feb 1, 2008</p>
					<p class="last">State Securities Law Exam</p>
				</li>
				
				<li class="col-lg-12 col-md-12 col-sm-12 col-xs-12  py-3 px-auto">
					<div class="exam" style="font-size:22px;">
						Series 3 - National Commodity Futures Examination
					</div>
					<p class="date" style="font-size:20px">Jan 30, 2012</p>
					<p class="last">General Industry/Products Exam</p>
				</li>
				
				<li class="col-lg-12 col-md-12 col-sm-12 col-xs-12  py-3 px-auto">
					<div class="exam" style="font-size:22px;">
						Series 7 - General Securities Representative Examination
					</div>
					<p class="date" style="font-size:20px">Dec 17, 2007</p>
					<p class="last">General Industry/Products Exam</p>
				</li>
			</ul>
			
		</div>
	</section>
	
	<section class="section services py-5">
		<div class="container">
			<h1>MY SERVICES</h1>
			<hr style="width:150px; height:3px; margin-left:5rem;">
			<div class="container-fluid justify-content-center">
				<div class="row text-center">
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>STOCKS</h3>
						<p>Stocks are bought &amp; sold  predominantly on stock exchanges, though there can be private  sales as well, they are the  foundation of every portfolio. Historically, they have outper- formed most other investments</p>
					</div>
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mx-auto my-5 px-2 py-1" style="background:#EBEBEB;">
						<h5>CRYPTOCURRENCY</h5>
						<p>It’s hard to evaluate the exact number of cryptocurrencies, especially since new ones are probably being created as we speak, but current estimations stand at nearly a thousand. Let’s make your crypto experience an easy one for you. </p>
					</div>
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>SECURITY ON INVESTMENTS</h3>
						<p>Our Investment platform gives a certain degree on security of the clients Equity, making sure to avoid leveraged risk on investment margin. </p>
					</div>
				</div>
				
				<div class="row text-center">
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>PORTFOLIO MANAGEMENT</h3>
						<p>Professional portfolio management on investments equity on consistent returns and avoiding leverage risk . </p>
					</div>
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mx-auto my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>CONSULTATION</h3>
						<p>Have a chat with the expert on Investment options and opportunities to suit your financial goals. </p>
					</div>
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>REAL ESTATE</h3>
						<p>Buying, Owning and selling a home can sometimes feel like an emotional roller coaster. There are new processes to navigate and seemingly endless roadblocks to overcome. We are here to help! </p>
					</div>
				</div>
				
				
				<div class="row text-center">
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>ALGO MINING</h3>
						<p>Genetic algorithms are unique ways to solve complex problems by harnessing the power of nature. By applying these methods to predicting security prices, traders can optimize trading rules by identifying the best values to use for each parameter for a given security. </p>
					</div>
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mx-auto my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3> INVESTMENT PLANNING </h3>
						<p>Starting up an investment plan involves more than just choosing a few stocks to put money in. You need to consider your current financial situation and your goals. It’s also important to define your timeline and how much risk you’re willing to take on in order to determine your optimal asset allocation. This is why we’re here for you, let’s help you start the plan.  </p>
					</div>
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 px-1 py-1" style="background:#EBEBEB;">
						<h3>REIT-FUND</h3>
						<p>Trades on Market, passes Rental Income % to you as Dividend. REITs own Real Estate under Brokerage management. </p>
					</div>
				</div>
				
				
				<div class="row text-center">
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 mx-auto px-1 py-1" style="background:#EBEBEB;">
						<h3> MUTUAL FUNDS </h3>
						<p>Pool of Investment Equity, Traded in the financial market on consistent %ROI, on a Brokerage management. </p>
					</div>
					
					
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 my-5 mx-auto px-1 py-1" style="background:#EBEBEB;">
						<h3>BONDS</h3>
						<p>Bonds are debt securities that are issued by corporations and governments to raise funds. Investors purchase bonds by putting an upfront amount as an initial investment—called the principal. When the bond expires or matures—called the maturity date—the investors are paid back their principal. </p>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	<section class="section guide">
		<img src="assets/fxbg.jpg" class="fxbg" style="width:100%; height:500px;">
		<div class="container pb-5 mb-5" style="margin-top:-7rem;position:relative;z-index:10;">
			<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 py-5 px-2 mx-auto pb-5" style="background:#EBEBEB;font-size:20px;">
				<h1 class="text-center">BEGINNERS GUIDE</h1>
				<p>In the learning stages I do not think it’s possible to approach anything with a part time attitude and get an awesome results. Even if you fully commit yourself to something new it doesn’t guarantee you will get the results others are getting.</p>
				
				<p>So imagine if you don’t even really bother trying. Learning to trade has been the hardest thing I have ever had to do if you are looking to do the same I strongly suggest you should go all in or better don’t try.</p>
				
				<p>On the flip side, if you have spend 3 to 5 years mastering trading, the technical and your mindset, you’re getting epic results but you want to input less hours to explore other avenues then is 100% achievable. Find a trading style that suit you ( most likely swing trading ) and requires less time and you’re set.</p><br>
			</div>
		</div>
	</section>
	
	<section class="section testimonials pb-5">
		<div class="container text-center  justify-content-center">
			<i class="fas fa-graduation-cap px-5 py-5 " style="font-size:150px;margin-top:-10rem; color:white;background:black;position:relative;z-index:15;"></i><br>
				
			<h1 class="py-5" style="font-size:40px;">TESTIMONIALS</h1>
			
		</div>
		
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 text-left px-5">
					<i class="fas fa-quote-left py-3" style="font-size:30px;"></i>
						
					<p class=" pd-5">I am an incredibly busy person &amp; was feeling  stressed about how or where to invest my  money during the pandemic last year, I looked into the advert set up by this platform, reached  out, today i am very happy i did. The returns are more than i expected from the platform. Its  been 8 months &amp; my fortunes have turned around massively.</p>
						
					<hr style=" height:3px;">
						
					<div class="avatar">
						<img src="assets/german.jpeg" class="mx-3">
					
						<span><strong>Marko Schiffer</strong><br><p></p></span>
					</div>
				</div>
				
				
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 text-left px-5">
					<i class="fas fa-quote-left py-3" style="font-size:30px;"></i>
						
					<p class=" pd-5">She has that unique ability to see straight to the heart of any matter. She is smart, savvy &amp; deeply  spiritual career advisor your school never had. The world would be a very different place if it had. Her advice saved me from exhausting detour down the wrong path. I cannot recommend her services enough.</p>
						
					<hr style=" height:3px;">
						
					<div class="avatar">
						<img src="assets/spanish.jpeg" class="mx-3">
					
						<span><strong>Erico Calderón López</strong><br><p></p></span>
					</div>
				</div>
			</div>
		</div>
		
	</section>
	
	
	<section class="section contactme py-5"  style="background:#21262D;color:#EBEBEB;">
		<div class="container py-5">
			<h1>CONTACT ME</h1>
			<hr style="width:150px; height:3px; margin-left:5rem;">
			<div class="row py-5 text-center">
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
					<img src="assets/contact.jpeg" style="width:50%; height:100%; border-radius:50%;" class="py-auto py-5">
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 py-5">
					<i class="fas fa-phone"> Phone</i><br>
					<a href="tel:16174106260">+1 (617) -410 -6260</a>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 py-5">
					<i class="fas fa-envelope"> Mail</i><br>
					<a href="mailto:contact@claireannesteinglass.com">me@something.com</a>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 py-5">
					<i class="fas fa-phone"> Address</i><br>
					<p>New York, NY</p>
				</div>
			
			
				<div class="container-fluid col-lg-6  col-md-6 col-sm-12 col-xs-12 ">
					<form method="post"  action="contact.php" data-parsley-validate="">
						<input type="text" class="form-control" name="visitor_name" required="" placeholder="Full Name:">
						<input type="email" class="form-control" name="visitor_email" data-parsley-trigger="change" required="" placeholder="Your Email:">
						<input type="text" class="form-control" name="phone_number" required="" placeholder="Your Mobile Number:">
						<input type="text" class="form-control" name="visitor_location" required="" placeholder="Your Location:">
					</div>
				
					<div class="container-fluid col-lg-6  col-md-6 col-sm-12 col-xs-12">
						<input type="text" class="form-control" name="email_title" required="" placeholder="Subject of Message:">
					
						<textarea id="message" class="form-control" name="visitor_message" data-parsley-trigger="keyup" data-parsley-minlength="20" data-parsley-maxlength="100" data-parsley-minlength-message="Come on! You need to enter at least a 20 character comment.." data-parsley-validation-threshold="10" placeholder="Your Message:"></textarea>

						<br>	
				
						<input type="submit" class="btn btn-primary" value="Submit">
					</form>
				</div>
			</div>
		</div>
	</section>
	
		
	<footer class="footer">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-12 text-center">
					<div class="sm-icons">
						<a href="https://wa.me/16174106260" class="fa fa-whatsapp"></a>
						
						<a href="https://t.me/clairesteinglass"class="fa fa-telegram"></a>
						
						<a href="mailto:contact@claireannesteinglass.com" class="fa fa-envelope"></a>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<hr>
	<footer class="footer">
		<div class="container text-foot text-center">
			<p class="mb-0">Copyright © 2021 Claire Anne Steinglass.</p>
		</div>
	</footer>



<!--==============Extras===============-->
	
	<!--=====back_to_top======-->
	<a href="#" class="back-to-top rounded text-center" id="back-to-top">
		<i class="fas fa-chevron-up d-block"> </i>
	</a>
	
	<!--=====hover_icons======-->
	<div class="contactleft" id="contactleft">
		<a href="https://wa.me/16174106260" class="fa fa-whatsapp fa-3x whatsapp animate__animated animate__bounce"></a>
		<a href="https://wa.me/16174106260" class="extra">Send a whatsapp message now !!</a>
	</div>
	

		
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script src="https://kit.fontawesome.com/6d734cb07b.js" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
	<script src="js/parsley.min.js"></script>
	<script src="js/jquery-3.6.0.js"></script>
	<script src="js/index.js"></script>
</body>

</html>
