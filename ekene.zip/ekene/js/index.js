




//reviews glide
new Glide('.reviews',{
	draggable:true,
	autoplay:5000,
	perView:1,
	gap:20,
	}).mount()


//back-to-top
if ($('#back-to-top').length) {
    var scrollTrigger = 100, // px
        backToTop = function () {
            var scrollTop = $(window).scrollTop();
            if (scrollTop > scrollTrigger) {
                $('#back-to-top').addClass('show');
            } else {
                $('#back-to-top').removeClass('show');
            }
        };
    backToTop();
    $(window).on('scroll', function () {
        backToTop();
    });
    $('#back-to-top').on('click', function (e) {
        e.preventDefault();
        $('html,body').animate({
            scrollTop: 0
        }, 700);
    });
}

//intro
var typed = new Typed('#typed', {
    stringsElement: '#typed-strings',
    backSpeed: 70,
    loop: true,
	loopCount: Infinity,
	showCursor: false,
	typeSpeed: 70,
  });
