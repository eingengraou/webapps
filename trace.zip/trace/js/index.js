

    
    var typed = new Typed('.element', {
	// Waits 1000ms after typing "First"
	strings: [' a Financial Consultant', ' a Stock Broker',' an Investment Adviser'],
    backSpeed: 100,
    loop: true,
	loopCount: Infinity,
	showCursor: false,
	typeSpeed: 70,
	});

